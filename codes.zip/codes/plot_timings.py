import matplotlib.pyplot as plt
import numpy as np
import pickle

try:
    hits = pickle.load(open("hits.p", 'rb'))
except IOError:
    print("Creating Binary File 1...")
    hits = np.loadtxt('timing_data_cache_hit.txt')
    hits = hits.astype(np.int64)
    pickle.dump(hits, open("hits.p", 'wb') )
try:
    misses = pickle.load(open("misses.p", 'rb'))
except IOError:
    print("Creating Binary File 2...")
    misses = np.loadtxt('timing_data_cache_miss.txt')
    misses = misses.astype(np.int64)
    pickle.dump(misses, open("misses.p", 'wb') )

y1 = np.zeros(len(hits))
y2 = np.zeros(len(misses))

for x in range(len(hits)):
	y1[x] = x
	y2[x] = x

# sexo = np.linspace(0, 1000000, 120000)

fig, ax = plt.subplots()
# ax.axis([1000000, 120000])

plt.scatter(y1, hits, s=4, label='Hits')
plt.scatter(y2, misses, s=4, label='Misses')
plt.xlabel('Attempts')
plt.ylabel('Timing')
plt.legend(loc='upper right')
plt.show()




# plt.plot(hits, y1, label = "Cache Hits")
# plt.plot(misses, y2, label = "Cache Misses")

# plt.title('Timing Data Cache Hits & Misses')
# plt.legend()
# plt.show()