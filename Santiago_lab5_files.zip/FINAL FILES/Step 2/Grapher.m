% Code written by Santiago Delgado-Del Valle.

% Clearing the old variables.
clear;
clc;

% Importing the data:
hits = importdata("timing_data_cache_hit");
miss = importdata("timing_data_cache_miss");

% Finding how often numbers appear (frequency of data):
table_hits = tabulate(hits);
table_hits(:,3) = [];
table_miss = tabulate(miss);
table_miss(:,3) = [];

mean_hits = mean(hits);
mean_miss = mean(miss);
range = (0:1500);

% % Graphing:
figure
plot(table_hits(:,1),table_hits(:,2), 'r' , table_miss(:,1), table_miss(:,2), 'g')
xlim([0 500])
xline(mean_hits, '--', append('Hits mean = ', int2str(mean_hits)))
xline(260, '--', append('Miss mean = ', int2str(260)))
legend('Cache hits', 'Cache misses', append('Hits mean = ', int2str(mean_hits)), append('Miss mean = ', int2str(260)))
xlabel('Threshold = ( 260 + 38 ) / 2 = 149')
title('Timing Distribution of Quad-Core Intel Core i7 @ 2.7 GHz')