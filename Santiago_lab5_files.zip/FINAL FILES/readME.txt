Welcome,

The program contains of multiple files to complete. The files and directories included are:
	-> attacker.c
	-> victim.c
	-> analysis.c
	-> plot_analysis.c
	-> keySolver.c
	-> Makefile
	-> Step 2 (dir)
		(Step 2) -> cacheCode.c
		(Step 2) -> Grapher.m

Info on specific files included:
	-> Makefile has been modified
	-> cacheCode.c (within Step 2 dir) is used to calculate the time threshold of the computer.
	-> Grapher.m takes the output files of cacheCode.c and graphs the outputs to find the threshold.
	-> keySolver.c is a file created that is similar to analysis.c, but has been modified to include an inverse s-box to decode the key.

How to run the code:
	1) Make sure to place all of the files on the root system, one level above the target library of openssl. So at the same root-level as openssl. Even cacheCode.c and Grapher.m, do not leave them on a different directory.
	2) Compile using Make all (using makefile) compile attacker, victim, and analysis. Then compile cacheCode.c using gcc and run it to get 2 output files.
	3) Run Grapher.m. with Matlab to find the timing threshold from the graph. Input the number on the Makefile for the threshold for 'run2'
	4) Open 2 terminal windows, time to run the attack. Run the victim on one terminal using './victim' and then input on the other terminal 'make run' to run the attacker from the Makefile. Make sure to input the correct T0 address before.
	5) After the attack has been completed and the two files have been created, type 'make run2' on either terminal. This will use analysis.c to analyze the data and create the result file. Then the make file will call the python function to graph the results. This is one of the outputs.
	6) Finally, to figure out the key the file keySolver.c has to be compiled and run. To compile it, simply type 'gcc keySolver.c' on the terminal. To execute the file type './a.out -t timing.bin -c cipher.bin -o analysis.txt' on the terminal.  This is because the file is based on analysis.c, but it does not use the analysis.txt.